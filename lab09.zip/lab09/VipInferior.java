package lab09;

public class VipInferior extends Vip {
	public VipInferior(double taxaAdicional) {
		super(taxaAdicional);
	}
}
