package lab09;

public class IngressoMeia extends IngressoNormal {

	public double getValorFinal() {
		return super.getValorFinal() / 2;
	}

}
